//
//  AppDelegate.h
//  BreakpointDebug
//
//  Created by 郑冰津 on 2016/12/5.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


/*
 断点调试:http://www.jianshu.com/p/4b1cde902f2d 普通断点,swift断点,全局/异常断点,OpenGL ES断点,符号断点,测试错误断点.
 http://www.cocoachina.com/ios/20140526/8555.html  Edit Scheme  开启僵尸对象(解决重复释放问题) Static Analyzer（静态分析）unrecognized selector send to instancd 快速定位
 https://my.oschina.net/u/219482/blog/123031  在xcode调试断点不能停在代码区的终极解决方案
 http://www.tuicool.com/articles/EbMRVj2 LLDB命令[[self view] recursiveDescription]
 让NSLog更加智能
 虽然NSLog非常有用，但是在真机上，从NSLog打印出来的任何内容都会被保留，隐藏所有人都可以看到——只需要将设备连接到电脑，然后打开Xcode中的organiser，并定位到console，就可以看到每条log信息。可能你会意识到，这会带来一些严重的影响！想一下，如果你将一些保密的算法逻辑，或者用户密码打印到控制台！因此，如果苹果检测到在production build中，输出许多内容到控制台时，你的应用可能会被苹果拒绝上架到商店。
 #ifdef DEBUG
 #define DMLog(...) NSLog(@"%s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
 #else
 #define DMLog(...) do { } while (0)
 
 
 http://www.cocoachina.com/industry/20130701/6514.html  LLDB打印结果
 */

