//
//  Test_VC.m
//  BreakpointDebug
//
//  Created by 郑冰津 on 2016/12/5.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_VC.h"

@interface Test_VC ()

@end

@implementation Test_VC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIImageView *imageV = [[UIImageView alloc]initWithImage:[self.class getSubImage:0]];
    imageV.frame = CGRectMake(0, 0, 400, 500);
    [self.view addSubview:imageV];
}

//截取部分图像
+(UIImage*)getSubImage:(char)ulUserHeader {
    
//    void *by = "2534253425";
//    void *a  = malloc(sizeof(1));
//    memcpy(a, by, sizeof(by));
//    NSLog(@"%s",a);
//    free(a);
    UIImage * sourceImage = [UIImage imageNamed:@"header.jpg"];
    CGRect rect = CGRectMake(0 , 0, 2000, 1000);
    CGImageRef imageRef = CGImageCreateWithImageInRect([sourceImage CGImage], rect);
    UIImage* smallImage = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
   
    return smallImage;
}

#pragma mark -----------UITableViewDelegate,UITableViewDataSource-----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IdentifierCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    //    cell.textLabel.text =
    cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell" forIndexPath:indexPath];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}


@end




