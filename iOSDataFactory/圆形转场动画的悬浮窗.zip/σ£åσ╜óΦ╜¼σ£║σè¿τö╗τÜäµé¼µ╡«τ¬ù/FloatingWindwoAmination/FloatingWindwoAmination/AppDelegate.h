//
//  AppDelegate.h
//  FloatingWindwoAmination
//
//  Created by huangzengquan on 16/5/25.
//  Copyright © 2016年 huangzengquan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FloatingWindow.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property(strong, nonatomic)UIWindow *window;
@property(strong, nonatomic)FloatingWindow *floatWindow;

@end

