//
//  YYTextEditExample.m
//  YYKitExample
//
//  Created by ibireme on 15/9/3.
//  Copyright (c) 2015 ibireme. All rights reserved.
//

#import "YYTextEditExample.h"
#import "YYText.h"
#import "YYImage.h"
#import "UIImage+YYWebImage.h"
#import "UIView+YYAdd.h"
#import "NSBundle+YYAdd.h"
#import "NSString+YYAdd.h"
#import "UIControl+YYAdd.h"
#import "CALayer+YYAdd.h"
#import "NSData+YYAdd.h"
#import "UIGestureRecognizer+YYAdd.h"

@interface YYTextEditExample () <YYTextViewDelegate, YYTextKeyboardObserver>
@property (nonatomic, assign) YYTextView *textView;
@property (nonatomic, strong) UIImageView *imageView;
@end

@implementation YYTextEditExample

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    if ([self respondsToSelector:@selector(setAutomaticallyAdjustsScrollViewInsets:)]) {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    __weak typeof(self) _self = self;
    
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:@"\n\n这是最好的时代，这是最坏的时代；这是智慧的时代，这是愚蠢的时代；这是信仰的时期，这是怀疑的时期；这是光明的季节，这是黑暗的季节；这是希望之春，这是失望之冬；人们面前有着各样事物，人们面前一无所有；人们正在直登天堂，人们正在直下地狱。"];
    text.yy_font = [UIFont fontWithName:@"Times New Roman" size:20];
    text.yy_lineSpacing = 4;
    text.yy_firstLineHeadIndent = 20;
    
//    YYTextView *textView = [YYTextView new];
    YYTextView *textView = [[YYTextView alloc]initWithFrame:CGRectMake(64, 64, 200, 300)];
    textView.attributedText = text;
//    textView.size = self.view.size;
    textView.textContainerInset = UIEdgeInsetsMake(10, 10, 10, 10);
    textView.delegate = self;
    if (kiOS7Later) {
        textView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    } else {
        textView.height -= 64;
    }
//    textView.contentInset = UIEdgeInsetsMake(64, 0, 0, 0);
//    textView.scrollIndicatorInsets = textView.contentInset;
    textView.selectedRange = NSMakeRange(text.length, 0);
    [self.view addSubview:textView];
    self.textView = textView;
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [textView becomeFirstResponder];
//    });
    
//    [_self.textView endEditing:YES];
    _self.textView.verticalForm = YES;
    
    [[YYTextKeyboardManager defaultManager] addObserver:self];
}

- (void)dealloc {
    [[YYTextKeyboardManager defaultManager] removeObserver:self];
}
//- (void)setExclusionPathEnabled:(BOOL)enabled {
//    if (enabled) {
//        [self.textView addSubview:self.imageView];
//        UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.imageView.frame
//                                                        cornerRadius:self.imageView.layer.cornerRadius];
//        self.textView.exclusionPaths = @[path]; /// Set exclusion paths
//    } else {
//        [self.imageView removeFromSuperview];
//        self.textView.exclusionPaths = nil;
//    }
//}

//- (void)initImageView {
//    NSData *data = [NSData dataNamed:@"dribbble256_imageio.png"];
//    UIImage *image = [[YYImage alloc] initWithData:data scale:2];
//    UIImageView *imageView = [[YYAnimatedImageView alloc] initWithImage:image];
//    imageView.clipsToBounds = YES;
//    imageView.userInteractionEnabled = YES;
//    imageView.layer.cornerRadius = imageView.height / 2;
//    imageView.center = CGPointMake(kScreenWidth / 2, kScreenWidth / 2);
//    self.imageView = imageView;
//
//    
//    __weak typeof(self) _self = self;
//    UIPanGestureRecognizer *g = [[UIPanGestureRecognizer alloc] initWithActionBlock:^(UIPanGestureRecognizer *g) {
//        __strong typeof(_self) self = _self;
//        if (!self) return;
//        CGPoint p = [g locationInView:self.textView];
//        self.imageView.center = p;
//        UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.imageView.frame
//                                                        cornerRadius:self.imageView.layer.cornerRadius];
//        self.textView.exclusionPaths = @[path];
//    }];
//    [imageView addGestureRecognizer:g];
//}

- (void)edit:(UIBarButtonItem *)item {
    if (_textView.isFirstResponder) {
        
        [_textView resignFirstResponder];
        
    } else {
        [_textView becomeFirstResponder];
        
    }
}

#pragma mark text view



- (void)textViewDidBeginEditing:(YYTextView *)textView {
    UIBarButtonItem *buttonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                                                                target:self
                                                                                action:@selector(edit:)];
    self.navigationItem.rightBarButtonItem = buttonItem;
}

- (void)textViewDidEndEditing:(YYTextView *)textView {
    self.navigationItem.rightBarButtonItem = nil;
}


#pragma mark - keyboard

//- (void)keyboardChangedWithTransition:(YYTextKeyboardTransition)transition {
//    BOOL clipped = NO;
//    if (_textView.isVerticalForm && transition.toVisible) {
//        CGRect rect = [[YYTextKeyboardManager defaultManager] convertRect:transition.toFrame toView:self.view];
//        if (CGRectGetMaxY(rect) == self.view.height) {
//            CGRect textFrame = self.view.bounds;
//            textFrame.size.height -= rect.size.height;
//            _textView.frame = textFrame;
//            clipped = YES;
//        }
//    }
//    
//    if (!clipped) {
//        _textView.frame = self.view.bounds;
//    }
//}

@end
