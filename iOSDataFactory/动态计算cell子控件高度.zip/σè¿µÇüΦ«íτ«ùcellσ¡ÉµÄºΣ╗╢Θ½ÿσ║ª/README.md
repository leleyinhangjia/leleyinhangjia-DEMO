# JPDiscover
类似朋友圈+网易新闻滑屏，一点一点来

## Overview
目前只实现了列表，其他的功能一点点更新吧。<br /> 
![screenshot](https://github.com/zhujia18/JPDiscover/blob/master/Screenshoot/1.png)
![screenshot](https://github.com/zhujia18/JPDiscover/blob/master/Screenshoot/2.png)
![screenshot](https://github.com/zhujia18/JPDiscover/blob/master/Screenshoot/3.png)
![screenshot](https://github.com/zhujia18/JPDiscover/blob/master/Screenshoot/effect.gif)
![screenshot](https://github.com/zhujia18/JPDiscover/blob/master/Screenshoot/frame.png)